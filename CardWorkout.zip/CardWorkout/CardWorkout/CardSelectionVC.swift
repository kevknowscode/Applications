//
//  CardSelectionVC.swift
//  CardWorkout
//
//  Created by Kev on 6/21/25.
//

import UIKit

class CardSelectionVC: UIViewController {
    
    @IBOutlet var cardImageView: UIImageView!
    
    
    @IBOutlet var Buttons: [UIButton]!
    
    var timer : Timer!
    
    var cards: [UIImage] = Card.allValues
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //        stopButton.layer.cornerRadius = 10
        //        restartButton.layer.cornerRadius = 10
        //        rulesButton.layer.cornerRadius = 10
        
        startTimer()
        for i in Buttons
        {
            i.layer.cornerRadius = 10
        }
        
        
    }
    
    func startTimer()
    {
        timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(showRandomImage), userInfo: nil, repeats: true)
    }
    
    @IBAction func stopButtonTapped(_ sender: UIButton) {
        
        timer.invalidate()
    }
    
    
    @IBAction func restartButtonTapped(_ sender: UIButton) {
        timer.invalidate()
        startTimer()
    }
    
    @objc func showRandomImage()
    {
        cardImageView.image = cards.randomElement() ?? UIImage(named: "AS")
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
